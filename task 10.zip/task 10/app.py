from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# Sample university programs and admission requirements
programs = {
    "computer_science": {
        "name": "Computer Science",
        "requirements": {
            "gpa": 3.0,
            "subjects": ["Mathematics", "Physics"],
            "tests": ["SAT/ACT"]
        },
        "deadline": "January 15",
        "description": "Our CS program focuses on software development, algorithms, and computer systems."
    },
    "business_administration": {
        "name": "Business Administration",
        "requirements": {
            "gpa": 2.8,
            "subjects": ["Mathematics", "English"],
            "tests": ["SAT/ACT"]
        },
        "deadline": "February 1",
        "description": "Develop leadership skills and business acumen in our renowned business program."
    },
    "biology": {
        "name": "Biology",
        "requirements": {
            "gpa": 3.2,
            "subjects": ["Biology", "Chemistry"],
            "tests": ["SAT/ACT"]
        },
        "deadline": "January 20",
        "description": "Explore life sciences with state-of-the-art research facilities."
    }
}

# Common questions and responses
common_questions = {
    "hello": ["Hello! Welcome to University Admissions. How can I help you today?", "Hi there! Ready to explore our programs?"],
    "deadline": "Application deadlines vary by program. Most are between January and February.",
    "requirements": "General requirements include a high school diploma, transcripts, and test scores. Program-specific requirements vary.",
    "cost": "Tuition is approximately $15,000 per year for in-state students and $30,000 for out-of-state.",
    "scholarships": "We offer merit-based and need-based scholarships. The application deadline is March 1.",
    "campus": "Our 200-acre campus features modern facilities, research labs, and excellent student housing.",
    "contact": "You can reach admissions at admissions@university.edu or (555) 123-4567."
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_message = request.form['message'].lower()
    response = ""

    # Check for program inquiries
    program_found = False
    for program_id, program_data in programs.items():
        if program_id in user_message or program_data['name'].lower() in user_message:
            response = f"Program: {program_data['name']}\n"
            response += f"Description: {program_data['description']}\n"
            response += f"Requirements: GPA {program_data['requirements']['gpa']}+, subjects: {', '.join(program_data['requirements']['subjects'])}, tests: {', '.join(program_data['requirements']['tests'])}\n"
            response += f"Application Deadline: {program_data['deadline']}"
            program_found = True
            break
    
    if not program_found:
        # Check for common questions
        for keyword, answer in common_questions.items():
            if keyword in user_message:
                if isinstance(answer, list):
                    response = random.choice(answer)
                else:
                    response = answer
                break
        
        if not response:
            # Default responses
            if "program" in user_message or "major" in user_message:
                program_list = "\n".join([f"- {p['name']}" for p in programs.values()])
                response = f"We offer these programs:\n{program_list}\nWhich one interests you?"
            elif "thank" in user_message:
                response = "You're welcome! Let me know if you have any other questions."
            elif "apply" in user_message or "application" in user_message:
                response = "You can apply online at our university website. Would you like the link?"
            else:
                response = "I'm here to help with university admissions. You can ask about programs, requirements, deadlines, or costs."

    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)